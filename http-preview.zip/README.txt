Wedding-online - patch tăng kích thước chữ trong ba thẻ lịch trình/địa điểm

Thay thế responsive.css, index.html và rsvp.html trong thư mục gốc repository.
responsive.css chứa quy tắc font mới cho tiêu đề, giờ, địa chỉ và icon của ba thẻ; index.html/rsvp.html đã cập nhật cache-busting cho responsive.css.


Responsive refactor (2026-10-20): responsive.css is now the single source of responsive breakpoints. Core breakpoints: 1100px, 850px, 650px, 550px, and 350px. Desktop/mobile section content uses the same semantic HTML; only layout rules change. The background music source in index.html uses the relative path assets/music/wedding-music.mp3.


Files merged from latest provided script.js. Couple-name fit threshold now matches the 550px mobile breakpoint; wedding audio URL is relative for GitHub Pages.


Logical layout blocks (2026-10-20)
- index.html uses data-layout-block names for hero, countdown, schedule, story, gallery, RSVP and guestbook.
- layout-system.css defines the order in grid-template-areas for desktop, tablet and mobile. These block boundaries do not create visible borders.
- Hero media is an independent picture block: wedding-hero.jpg is used above tablet widths, while wedding-mobile.jpg is used on narrow screens.
- To reorder page sections, change only grid-template-areas inside layout-system.css; keep each grid-area name paired with its .layout-block--* class.
- Existing site logic, Supabase configuration, RSVP handling, guestbook handling, and section IDs are preserved.
